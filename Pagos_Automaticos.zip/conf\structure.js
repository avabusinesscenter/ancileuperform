﻿
/**
structure.js (dynamic)
Published by ANCILE uPerform 5.30.0.1711
*/

var initStructure = function()
{
	try
	{
		//Sim Title
		engine.simTitle="Prueba de Concepto Pagos Automáticos";

		group1=new Group(
		{caption:"%26%238234%3BPago%20autom%26%23225%3Btico%20de%20facturas%20-%20SAP%20NetWeaver%20Portal%20-%20Internet%20Explorer%26%238236%3B"}
		);

			step_f762844149=new Step(
			{screen:{file:"i0000001.jpg",overlays:null},cursor:"c0000001.png",audio:"-908712514.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"f762844149",content:[{text:"%3Cspan class=%2206af4275aab046c78940932d32854a2c%22%3EHaga clic en el menú ‪Pagos.%3C/span%3E"}]}
			);

				action_581396654=new ActionMouse(
				{button:"leftclick",numberOfClicks:1,isDefault:true,modifiers:{alt:false,ctrl:false,shift:false},rectangle:{x:143,y:40,width:53,height:18},cursor:{file:"c0000002.png",x:169,y:49},route:"f1493550251",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"http_%2F%2Forionamerica.aacc.pre.corp%2Firj%2Fportal",secondaryCsh:"Pago%20autom%26%23225%3Btico%20de%20facturas%20-%20SAP%20NetWeaver%20Portal",tertiaryCsh:"obnNavIFrame%7C%26%23193%3Brea%20interna%20de%20desktop%20%20%20%7CFavoritos%20de%20portal%20%7CUntitled%7CisolatedWorkArea%7Citsframe1_20170215001330.0331260%7CITSTERMFRAME%7ChelpPanelContent",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_581396654"}
				);

			step_f762844149.addAction(action_581396654);

				note_581396654=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:575,y:92,width:161,height:42},file:"581396654.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:196,y:58},rectangle:{x:567,y:87,width:172,height:52},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_581396654"}
				);

			step_f762844149.addNote(note_581396654);

		group1.addStep(step_f762844149);

		group2=new Group(
		{caption:"%26%238234%3BProveedores%20-%20SAP%20NetWeaver%20Portal%20-%20Internet%20Explorer%26%238236%3B"}
		);

			step_f1493550251=new Step(
			{screen:{file:"i0000002.jpg",overlays:null},cursor:"c0000003.png",audio:"-897899074.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"f1493550251",content:[{text:"%3Cspan class=%228719ca1c3df24e5ebb282c759d171a0c%22%3E%3Cspan class=%229b60db8f9ed14109a30cb4c497d16950%22%3EHaga clic en la opción %3Cb%3E‪Contabilidad%3C/b%3E‬.%3C/span%3E%3C/span%3E"}]}
			);

				action_f775803307=new ActionMouse(
				{button:"leftclick",numberOfClicks:1,isDefault:true,modifiers:{alt:false,ctrl:false,shift:false},rectangle:{x:140,y:60,width:71,height:16},cursor:{file:"c0000004.png",x:175,y:68},route:"1792064519",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"http_%2F%2Forionamerica.aacc.pre.corp%2Firj%2Fportal",secondaryCsh:"Proveedores%20-%20SAP%20NetWeaver%20Portal",tertiaryCsh:"obnNavIFrame%7C%26%23193%3Brea%20interna%20de%20desktop%20%20%20%7CFavoritos%20de%20portal%20%7CUntitled%7CLogon%20Error%20Message%7ChelpPanelContent",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f775803307"}
				);

			step_f1493550251.addAction(action_f775803307);

				note_f775803307=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:288,y:148,width:170,height:63},file:"f775803307.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:211,y:76},rectangle:{x:280,y:143,width:181,height:73},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f775803307"}
				);

			step_f1493550251.addNote(note_f775803307);

		group2.addStep(step_f1493550251);

		group3=new Group(
		{caption:"%26%238234%3BDocumentos%20-%20SAP%20NetWeaver%20Portal%20-%20Internet%20Explorer%26%238236%3B"}
		);

			step_1792064519=new Step(
			{screen:{file:"i0000003.jpg",overlays:null},cursor:"c0000005.png",audio:"-904124994.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"1792064519",content:[{text:"%3Cspan class=%227ffe1d9835df4b4e831fb4db3cf44526%22%3E%3Cspan class=%22e9791ef86ed041fc8b9bcd82ff039bf1%22%3EHaga clic en la carpeta %3Cb%3EPagos%3C/b%3E del árbol ‪Documentos‬.%3C/span%3E%3C/span%3E"}]}
			);

				action_f1372978791=new ActionMouse(
				{button:"leftclick",numberOfClicks:1,isDefault:true,modifiers:{alt:false,ctrl:false,shift:false},rectangle:{x:10,y:183,width:208,height:19},cursor:{file:"c0000006.png",x:114,y:192},route:"426957236",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"http_%2F%2Forionamerica.aacc.pre.corp%2Firj%2Fportal",secondaryCsh:"Documentos%20-%20SAP%20NetWeaver%20Portal",tertiaryCsh:"obnNavIFrame%7C%26%23193%3Brea%20interna%20de%20desktop%20%20%20%7CFavoritos%20de%20portal%20%7CUntitled%7ChelpPanelContent",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f1372978791"}
				);

			step_1792064519.addAction(action_f1372978791);

				note_f1372978791=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:290,y:230,width:169,height:63},file:"f1372978791.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:218,y:202},rectangle:{x:282,y:225,width:180,height:73},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f1372978791"}
				);

			step_1792064519.addNote(note_f1372978791);

		group3.addStep(step_1792064519);

			step_426957236=new Step(
			{screen:{file:"i0000003.jpg",overlays:[{rectangle:{x:213,y:128,width:4,height:7},file:"i0000004_1.jpg"},{rectangle:{x:13,y:189,width:7,height:7},file:"i0000004_2.jpg"},{rectangle:{x:2,y:208,width:220,height:363},file:"i0000004_3.jpg"},{rectangle:{x:2,y:649,width:685,height:21},file:"i0000004_4.jpg"}]},cursor:"c0000007.png",audio:"-911137346.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"426957236",content:[{text:"%3Cspan class=%22e158cd11b6cc44f9b30238c69694fbf1%22%3EHaga clic en el elemento ‪%3Cb%3EPago automático de facturas%3C/b%3E, de la carpeta Pagos‬.%3C/span%3E"}]}
			);

				action_1591203597=new ActionMouse(
				{button:"leftclick",numberOfClicks:1,isDefault:true,modifiers:{alt:false,ctrl:false,shift:false},rectangle:{x:2,y:203,width:220,height:19},cursor:{file:"c0000008.png",x:112,y:212},route:"410556269",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"http_%2F%2Forionamerica.aacc.pre.corp%2Firj%2Fportal",secondaryCsh:"Documentos%20-%20SAP%20NetWeaver%20Portal",tertiaryCsh:"obnNavIFrame%7C%26%23193%3Brea%20interna%20de%20desktop%20%20%20%7CFavoritos%20de%20portal%20%7CUntitled%7ChelpPanelContent",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_1591203597"}
				);

			step_426957236.addAction(action_1591203597);

				note_1591203597=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:317,y:256,width:227,height:84},file:"1591203597.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:222,y:222},rectangle:{x:309,y:251,width:238,height:94},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_1591203597"}
				);

			step_426957236.addNote(note_1591203597);

		group3.addStep(step_426957236);

		group4=new Group(
		{caption:"%26%238234%3BPagos%20autom%26%23225%3Bticos%3A%20Status%26%238236%3B"}
		);

			step_410556269=new Step(
			{screen:{file:"i0000005.jpg",overlays:null},cursor:"c0000009.png",audio:"-917363266.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"410556269",content:[{text:"%3Cspan class=%225d9190795ed14b3e892d4054a09eb4ab%22%3E%3Cspan class=%2277022987dd564f57ad06988891b05729%22%3EHaga clic en el campo %3Cb%3EDía de ejecución%3C/b%3E‬.%3C/span%3E%3C/span%3E"}]}
			);

				action_788132183=new ActionMouse(
				{button:"leftclick",numberOfClicks:1,isDefault:true,modifiers:{alt:false,ctrl:false,shift:false},rectangle:{x:196,y:95,width:79,height:15},cursor:{file:"c0000010.png",x:235,y:102},route:"831791115",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"portal_content%2Fes.san.erp.carpeta_san%2Fes.san.erp.carpeta_mexico%2Fes.san.erp.capreta_fi%2Fes.san.erp.carpeta_roles%2Fes.san.erp.rol_zecc_mx_fi_lanto%2Fes.san.erp.workset_pagos%2Fes.san.erp.workset_contabilidad%2Fes.san.erp.workset_pagos%2Fes.san.erp.iview_pago_automatico_facturas",secondaryCsh:"",tertiaryCsh:"",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_788132183"}
				);

			step_410556269.addAction(action_788132183);

				note_788132183=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:381,y:98,width:162,height:63},file:"788132183.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:275,y:102},rectangle:{x:373,y:93,width:173,height:73},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_788132183"}
				);

			step_410556269.addNote(note_788132183);

		group4.addStep(step_410556269);

			step_831791115=new Step(
			{screen:{file:"i0000005.jpg",overlays:null},cursor:"c0000009.png",audio:"-906549826.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"831791115",content:[{text:"%3Cp%3E%3Cspan class=%225aae9dfeb0c54e36b0141aa15921a5ef%22%3E %3Cp%3EEscriba %22‪15.02.2017‬%22 en el campo %3Cb%3EDía de ejecución%3C/b%3E.%3C/p%3E %3C/span%3E%3C/p%3E"}]}
			);

				action_f2128479180=new ActionEditExact(
				{text:"15.02.2017",caseSensitive:false,pattern:"",hint:"15.02.2017",isDefault:true,rectangle:{x:188,y:95,width:84,height:14},cursor:{file:"c0000009.png",x:230,y:102},route:"1955716097",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"",secondaryCsh:"",tertiaryCsh:"",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f2128479180"}
				);

			step_831791115.addAction(action_f2128479180);

				note_f2128479180=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:382,y:207,width:190,height:66},file:"f2128479180.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:272,y:109},rectangle:{x:374,y:202,width:201,height:76},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f2128479180"}
				);

			step_831791115.addNote(note_f2128479180);

				note_f438530897=new Note(
				{icon:{rectangle:{x:367,y:84,width:32,height:32},file:"noteicon_2.png"},image:{hyperlinks:null,rectangle:{x:399,y:84,width:185,height:69},file:"831791115_f438530897.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:0,r:255,g:255,b:255},borderWidth:2,rectangle:{x:362,y:79,width:227,height:79},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:false,notetailAuto:false,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:""}
				);

			step_831791115.addNote(note_f438530897);

		group4.addStep(step_831791115);

			step_1955716097=new Step(
			{screen:{file:"i0000005.jpg",overlays:[{rectangle:{x:193,y:94,width:98,height:43},file:"i0000007_1.jpg"}]},cursor:"c0000013.png",audio:"-912775746.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"1955716097",content:[{text:"%3Cspan class=%2273c7444f96ec424ebe324d440bcc3840%22%3E%3Cspan class=%2297f104fb82e842b7837bd583cd11b7d8%22%3EHaga clic en el campo %3Cb%3EIdentificador%3C/b%3E.%3C/span%3E%3C/span%3E"}]}
			);

				action_f931918307=new ActionMouse(
				{button:"leftclick",numberOfClicks:1,isDefault:true,modifiers:{alt:false,ctrl:false,shift:false},rectangle:{x:190,y:121,width:43,height:16},cursor:{file:"c0000014.png",x:211,y:129},route:"1435596416",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"portal_content%2Fes.san.erp.carpeta_san%2Fes.san.erp.carpeta_mexico%2Fes.san.erp.capreta_fi%2Fes.san.erp.carpeta_roles%2Fes.san.erp.rol_zecc_mx_fi_lanto%2Fes.san.erp.workset_pagos%2Fes.san.erp.workset_contabilidad%2Fes.san.erp.workset_pagos%2Fes.san.erp.iview_pago_automatico_facturas",secondaryCsh:"",tertiaryCsh:"",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f931918307"}
				);

			step_1955716097.addAction(action_f931918307);

				note_f931918307=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:309,y:203,width:175,height:42},file:"f931918307.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:233,y:137},rectangle:{x:301,y:198,width:186,height:52},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f931918307"}
				);

			step_1955716097.addNote(note_f931918307);

		group4.addStep(step_1955716097);

			step_1435596416=new Step(
			{screen:{file:"i0000005.jpg",overlays:[{rectangle:{x:190,y:94,width:101,height:63},file:"i0000008_1.jpg"}]},cursor:"c0000015.png",audio:"-919788098.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"1435596416",content:[{text:"%3Cp%3E%3Cspan class=%22c1d68ae84a7e420783d2f7409ef2d60b%22%3E %3Cp%3EEscriba %22‪MX01V‬%22 en el campo %3Cb%3EIdentificador%3C/b%3E.%3C/p%3E %3C/span%3E%3C/p%3E"}]}
			);

				action_1339040818=new ActionEditExact(
				{text:"MX01V",caseSensitive:false,pattern:"",hint:"MX01V",isDefault:true,rectangle:{x:189,y:122,width:44,height:15},cursor:{file:"c0000015.png",x:211,y:129},route:"832270279",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"",secondaryCsh:"",tertiaryCsh:"",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_1339040818"}
				);

			step_1435596416.addAction(action_1339040818);

				note_1339040818=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:320,y:201,width:190,height:46},file:"1339040818.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:233,y:137},rectangle:{x:312,y:196,width:201,height:56},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_1339040818"}
				);

			step_1435596416.addNote(note_1339040818);

		group4.addStep(step_1435596416);

			step_832270279=new Step(
			{screen:{file:"i0000005.jpg",overlays:[{rectangle:{x:193,y:94,width:85,height:39},file:"i0000009_1.jpg"}]},cursor:"c0000017.png",audio:"-926014018.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"832270279",content:[{text:"%3Cspan class=%2205bb77ff06914b68a06731499104f60a%22%3E%3Cspan class=%223173e999e2504a528091d2e14ebf54de%22%3EHaga clic en la pestaña %3Cb%3EParámetro%3C/b%3E.%3C/span%3E%3C/span%3E"}]}
			);

				action_f363618439=new ActionMouse(
				{button:"leftclick",numberOfClicks:1,isDefault:true,modifiers:{alt:false,ctrl:false,shift:false},rectangle:{x:107,y:174,width:106,height:19},cursor:{file:"c0000018.png",x:160,y:183},route:"18755776",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"portal_content%2Fes.san.erp.carpeta_san%2Fes.san.erp.carpeta_mexico%2Fes.san.erp.capreta_fi%2Fes.san.erp.carpeta_roles%2Fes.san.erp.rol_zecc_mx_fi_lanto%2Fes.san.erp.workset_pagos%2Fes.san.erp.workset_contabilidad%2Fes.san.erp.workset_pagos%2Fes.san.erp.iview_pago_automatico_facturas",secondaryCsh:"",tertiaryCsh:"",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f363618439"}
				);

			step_832270279.addAction(action_f363618439);

				note_f363618439=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:322,y:239,width:173,height:42},file:"f363618439.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:213,y:193},rectangle:{x:314,y:234,width:184,height:52},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f363618439"}
				);

			step_832270279.addNote(note_f363618439);

		group4.addStep(step_832270279);

		group5=new Group(
		{caption:"%26%238234%3BPagos%20autom%26%23225%3Bticos%3A%20Par%26%23225%3Bmetros%26%238236%3B"}
		);

			step_18755776=new Step(
			{screen:{file:"i0000010.jpg",overlays:null},cursor:"c0000019.png",audio:"1813084571.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"18755776",content:[{text:"%3Cspan class=%227a356ff2a47d431ebd3b9f4c6d9d8c3a%22%3E%3Cspan class=%2273bec640017e46dbb3221c48fcbcac47%22%3EHaga clic en el campo %3Cb%3EFe.contabilización%3C/b%3E.%3C/span%3E%3C/span%3E"}]}
			);

				action_f129564143=new ActionMouse(
				{button:"leftclick",numberOfClicks:1,isDefault:true,modifiers:{alt:false,ctrl:false,shift:false},rectangle:{x:193,y:204,width:88,height:13},cursor:{file:"c0000020.png",x:237,y:210},route:"2100224169",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"portal_content%2Fes.san.erp.carpeta_san%2Fes.san.erp.carpeta_mexico%2Fes.san.erp.capreta_fi%2Fes.san.erp.carpeta_roles%2Fes.san.erp.rol_zecc_mx_fi_lanto%2Fes.san.erp.workset_pagos%2Fes.san.erp.workset_contabilidad%2Fes.san.erp.workset_pagos%2Fes.san.erp.iview_pago_automatico_facturas",secondaryCsh:"",tertiaryCsh:"",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f129564143"}
				);

			step_18755776.addAction(action_f129564143);

				note_f129564143=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:369,y:96,width:176,height:63},file:"f129564143.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:281,y:204},rectangle:{x:361,y:91,width:187,height:73},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f129564143"}
				);

			step_18755776.addNote(note_f129564143);

		group5.addStep(step_18755776);

			step_2100224169=new Step(
			{screen:{file:"i0000010.jpg",overlays:null},cursor:"c0000019.png",audio:"1315691710.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"2100224169",content:[{text:"%3Cp%3E%3Cspan class=%22c11511a0cfc54fe4a9f01d8124fdfd74%22%3E %3Cp%3EEscriba %22‪15.02.2017‬%22 en el campo %3Cb%3EFe.contabilización%3C/b%3E.%3C/p%3E %3C/span%3E%3C/p%3E"}]}
			);

				action_f1934273030=new ActionEditExact(
				{text:"15.02.2017",caseSensitive:false,pattern:"",hint:"15.02.2017",isDefault:true,rectangle:{x:192,y:204,width:83,height:14},cursor:{file:"c0000019.png",x:233,y:211},route:"44424413",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"",secondaryCsh:"",tertiaryCsh:"",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f1934273030"}
				);

			step_2100224169.addAction(action_f1934273030);

				note_f1934273030=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:333,y:85,width:213,height:75},file:"f1934273030.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:275,y:204},rectangle:{x:325,y:80,width:224,height:85},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f1934273030"}
				);

			step_2100224169.addNote(note_f1934273030);

		group5.addStep(step_2100224169);

			step_44424413=new Step(
			{screen:{file:"i0000010.jpg",overlays:[{rectangle:{x:195,y:202,width:427,height:16},file:"i0000012_1.jpg"}]},cursor:"c0000023.png",audio:"-794839259.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"44424413",content:[{text:"%3Cspan class=%227c1db6e1f2bb45cd9f1aacb96f1749be%22%3E%3Cspan class=%22b0749e94057e4b42847537921715a91c%22%3E%3Cspan class=%22995c22b21030447d8ec21786cb2d5638%22%3EHaga clic en el campo %3Cb%3EDoc.creados hasta%3C/b%3E.%3C/span%3E%3C/span%3E%3C/span%3E"}]}
			);

				action_1301489969=new ActionMouse(
				{button:"leftclick",numberOfClicks:1,isDefault:true,modifiers:{alt:false,ctrl:false,shift:false},rectangle:{x:520,y:202,width:85,height:16},cursor:{file:"c0000024.png",x:562,y:210},route:"f1660445675",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"portal_content%2Fes.san.erp.carpeta_san%2Fes.san.erp.carpeta_mexico%2Fes.san.erp.capreta_fi%2Fes.san.erp.carpeta_roles%2Fes.san.erp.rol_zecc_mx_fi_lanto%2Fes.san.erp.workset_pagos%2Fes.san.erp.workset_contabilidad%2Fes.san.erp.workset_pagos%2Fes.san.erp.iview_pago_automatico_facturas",secondaryCsh:"",tertiaryCsh:"",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_1301489969"}
				);

			step_44424413.addAction(action_1301489969);

				note_1301489969=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:659,y:249,width:173,height:63},file:"1301489969.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:605,y:218},rectangle:{x:651,y:244,width:184,height:73},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_1301489969"}
				);

			step_44424413.addNote(note_1301489969);

		group5.addStep(step_44424413);

			step_f1660445675=new Step(
			{screen:{file:"i0000010.jpg",overlays:[{rectangle:{x:195,y:202,width:429,height:36},file:"i0000013_1.jpg"}]},cursor:"c0000025.png",audio:"-936001760.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"f1660445675",content:[{text:"%3Cp%3E%3Cspan class=%225c4b4384160f4c01b1b0df40a15ba946%22%3E %3Cp%3EEscriba %22‪15.02.2017‬%22 en el campo %3Cb%3EDoc.creados hasta%3C/b%3E.%3C/p%3E %3C/span%3E%3C/p%3E"}]}
			);

				action_673083505=new ActionEditExact(
				{text:"15.02.2017",caseSensitive:false,pattern:"",hint:"15.02.2017",isDefault:true,rectangle:{x:520,y:203,width:85,height:12},cursor:{file:"c0000025.png",x:562,y:209},route:"1383047395",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"",secondaryCsh:"",tertiaryCsh:"",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_673083505"}
				);

			step_f1660445675.addAction(action_673083505);

				note_673083505=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:653,y:240,width:208,height:69},file:"673083505.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:605,y:215},rectangle:{x:645,y:235,width:219,height:79},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_673083505"}
				);

			step_f1660445675.addNote(note_673083505);

		group5.addStep(step_f1660445675);

			step_1383047395=new Step(
			{screen:{file:"i0000010.jpg",overlays:[{rectangle:{x:195,y:202,width:429,height:36},file:"i0000013_1.jpg"}]},cursor:"c0000025.png",audio:"-1917232721.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"1383047395",content:[{text:"%3Cspan class=%22512a83aebb964cc1942b116adfffdc79%22%3EHaga clic en el campo %3Cb%3E‪Sociedades ‬%3C/b%3Ede la sección Control de pagos..%3C/span%3E"}]}
			);

				action_1683179972=new ActionMouse(
				{button:"leftclick",numberOfClicks:1,isDefault:true,modifiers:{alt:false,ctrl:false,shift:false},rectangle:{x:27,y:305,width:400,height:18},cursor:{file:"c0000026.png",x:227,y:314},route:"1395435192",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"portal_content%2Fes.san.erp.carpeta_san%2Fes.san.erp.carpeta_mexico%2Fes.san.erp.capreta_fi%2Fes.san.erp.carpeta_roles%2Fes.san.erp.rol_zecc_mx_fi_lanto%2Fes.san.erp.workset_pagos%2Fes.san.erp.workset_contabilidad%2Fes.san.erp.workset_pagos%2Fes.san.erp.iview_pago_automatico_facturas",secondaryCsh:"",tertiaryCsh:"",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_1683179972"}
				);

			step_1383047395.addAction(action_1683179972);

				note_1683179972=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:514,y:368,width:263,height:63},file:"1683179972.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:427,y:323},rectangle:{x:506,y:363,width:274,height:73},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_1683179972"}
				);

			step_1383047395.addNote(note_1683179972);

		group5.addStep(step_1383047395);

			step_1395435192=new Step(
			{screen:{file:"i0000010.jpg",overlays:[{rectangle:{x:195,y:202,width:343,height:16},file:"i0000015_1.jpg"},{rectangle:{x:27,y:312,width:404,height:40},file:"i0000015_2.jpg"}]},cursor:"c0000029.png",audio:"1880341714.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"1395435192",content:[{text:"%3Cp%3E%3Cspan class=%2242e359497b9b494684de861025b8cc63%22%3E %3Cp%3EEscriba %22‪0077‬%22 en el campo %3Cb%3ESociedades%3C/b%3E para este caso práctico.%3C/p%3E %3C/span%3E%3C/p%3E"}]}
			);

				action_f703703834=new ActionEditExact(
				{text:"0077",caseSensitive:false,pattern:"",hint:"0077",isDefault:true,rectangle:{x:28,y:306,width:407,height:19},cursor:{file:"c0000029.png",x:231,y:315},route:"f243305334",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"",secondaryCsh:"",tertiaryCsh:"",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f703703834"}
				);

			step_1395435192.addAction(action_f703703834);

				note_f703703834=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:548,y:365,width:205,height:107},file:"f703703834.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:435,y:325},rectangle:{x:540,y:360,width:216,height:117},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f703703834"}
				);

			step_1395435192.addNote(note_f703703834);

		group5.addStep(step_1395435192);

			step_f243305334=new Step(
			{screen:{file:"i0000010.jpg",overlays:[{rectangle:{x:195,y:202,width:343,height:16},file:"i0000016_1.jpg"},{rectangle:{x:27,y:303,width:501,height:28},file:"i0000016_2.jpg"}]},cursor:"c0000031.png",audio:"-230189255.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"f243305334",content:[{text:"%3Cspan class=%22065950cd9c7e43688e1132081c51d15c%22%3EHaga clic en el botón match code %3Cb%3EVías pago%3C/b%3E de la sección Control de pagos.%3C/span%3E"}]}
			);

				action_f1576645623=new ActionMouse(
				{button:"leftclick",numberOfClicks:1,isDefault:true,modifiers:{alt:false,ctrl:false,shift:false},rectangle:{x:513,y:304,width:14,height:25},cursor:{file:"c0000032.png",x:520,y:316},route:"f441579497",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"portal_content%2Fes.san.erp.carpeta_san%2Fes.san.erp.carpeta_mexico%2Fes.san.erp.capreta_fi%2Fes.san.erp.carpeta_roles%2Fes.san.erp.rol_zecc_mx_fi_lanto%2Fes.san.erp.workset_pagos%2Fes.san.erp.workset_contabilidad%2Fes.san.erp.workset_pagos%2Fes.san.erp.iview_pago_automatico_facturas",secondaryCsh:"",tertiaryCsh:"",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f1576645623"}
				);

			step_f243305334.addAction(action_f1576645623);

				note_f1576645623=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:625,y:377,width:240,height:63},file:"f1576645623.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:527,y:329},rectangle:{x:617,y:372,width:251,height:73},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f1576645623"}
				);

			step_f243305334.addNote(note_f1576645623);

		group5.addStep(step_f243305334);

			step_f441579497=new Step(
			{screen:{file:"i0000010.jpg",overlays:[{rectangle:{x:195,y:202,width:343,height:16},file:"i0000017_1.jpg"},{rectangle:{x:27,y:303,width:501,height:49},file:"i0000017_2.jpg"}]},cursor:"c0000033.png",audio:"-371351756.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"f441579497",content:[{text:"%3Cspan class=%227a25aad581c44aada3763b278bb8dfe3%22%3E%3Cspan class=%228fb23fc448df4e12b970dc3cb40c0dae%22%3ESeleccione la opción %3Cb%3Ev%3C/b%3E, para efecto de este caso práctico.%3C/span%3E%3C/span%3E"}]}
			);

				action_f866657983=new ActionMouse(
				{button:"leftclick",numberOfClicks:1,isDefault:true,modifiers:{alt:false,ctrl:false,shift:false},rectangle:{x:431,y:333,width:82,height:19},cursor:{file:"c0000034.png",x:472,y:342},route:"1944003782",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"portal_content%2Fes.san.erp.carpeta_san%2Fes.san.erp.carpeta_mexico%2Fes.san.erp.capreta_fi%2Fes.san.erp.carpeta_roles%2Fes.san.erp.rol_zecc_mx_fi_lanto%2Fes.san.erp.workset_pagos%2Fes.san.erp.workset_contabilidad%2Fes.san.erp.workset_pagos%2Fes.san.erp.iview_pago_automatico_facturas",secondaryCsh:"",tertiaryCsh:"",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f866657983"}
				);

			step_f441579497.addAction(action_f866657983);

				note_f866657983=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:620,y:381,width:212,height:63},file:"f866657983.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:513,y:352},rectangle:{x:612,y:376,width:223,height:73},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f866657983"}
				);

			step_f441579497.addNote(note_f866657983);

		group5.addStep(step_f441579497);

			step_1944003782=new Step(
			{screen:{file:"i0000010.jpg",overlays:[{rectangle:{x:195,y:202,width:343,height:16},file:"i0000018_1.jpg"},{rectangle:{x:27,y:303,width:617,height:28},file:"i0000018_2.jpg"}]},cursor:"c0000035.png",audio:"663581587.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"1944003782",content:[{text:"%3Cspan class=%220453cece7e6a4c12a7dd0842b3dbfb43%22%3E%3Cspan class=%224e04826832fd49c2aee19a729ec5f476%22%3EHaga clic en el campo %3Cb%3ESig.fe.cont%3C/b%3E de la sección Control de pagos.%3C/span%3E%3C/span%3E"}]}
			);

				action_180752774=new ActionMouse(
				{button:"leftclick",numberOfClicks:1,isDefault:true,modifiers:{alt:false,ctrl:false,shift:false},rectangle:{x:513,y:310,width:114,height:13},cursor:{file:"c0000036.png",x:570,y:316},route:"816901891",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"portal_content%2Fes.san.erp.carpeta_san%2Fes.san.erp.carpeta_mexico%2Fes.san.erp.capreta_fi%2Fes.san.erp.carpeta_roles%2Fes.san.erp.rol_zecc_mx_fi_lanto%2Fes.san.erp.workset_pagos%2Fes.san.erp.workset_contabilidad%2Fes.san.erp.workset_pagos%2Fes.san.erp.iview_pago_automatico_facturas",secondaryCsh:"",tertiaryCsh:"",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_180752774"}
				);

			step_1944003782.addAction(action_180752774);

				note_180752774=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:698,y:372,width:193,height:84},file:"180752774.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:627,y:323},rectangle:{x:690,y:367,width:204,height:94},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_180752774"}
				);

			step_1944003782.addNote(note_180752774);

		group5.addStep(step_1944003782);

			step_816901891=new Step(
			{screen:{file:"i0000010.jpg",overlays:[{rectangle:{x:195,y:202,width:343,height:16},file:"i0000019_1.jpg"},{rectangle:{x:27,y:314,width:557,height:7},file:"i0000019_2.jpg"},{rectangle:{x:276,y:466,width:99,height:16},file:"i0000019_3.jpg"}]},cursor:"c0000037.png",audio:"186391702.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"816901891",content:[{text:"%3Cp%3E%3Cspan class=%22edcf3a0469b64713adfe9d7aaba92023%22%3E %3Cp%3EEscriba %22‪16.02.2017‬%22 en el campo %3Cb%3ESig.fe.cont%3C/b%3E.%3C/p%3E %3C/span%3E%3C/p%3E"}]}
			);

				action_f353188581=new ActionEditExact(
				{text:"16.02.2017",caseSensitive:false,pattern:"",hint:"16.02.2017",isDefault:true,rectangle:{x:515,y:307,width:115,height:18},cursor:{file:"c0000037.png",x:572,y:316},route:"f132197363",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"",secondaryCsh:"",tertiaryCsh:"",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f353188581"}
				);

			step_816901891.addAction(action_f353188581);

				note_f353188581=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:684,y:370,width:190,height:107},file:"f353188581.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:630,y:325},rectangle:{x:676,y:365,width:201,height:117},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f353188581"}
				);

			step_816901891.addNote(note_f353188581);

		group5.addStep(step_816901891);

			step_f132197363=new Step(
			{screen:{file:"i0000010.jpg",overlays:[{rectangle:{x:195,y:202,width:343,height:16},file:"i0000019_1.jpg"},{rectangle:{x:27,y:314,width:557,height:7},file:"i0000019_2.jpg"},{rectangle:{x:276,y:466,width:99,height:16},file:"i0000019_3.jpg"}]},cursor:"c0000037.png",audio:"1823766939.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"f132197363",content:[{text:"%3Cspan class=%22bc0ebcf3e12549e6b4a961990a572d4c%22%3E%3Cspan class=%22999bd025f19445529e0bb4aaf16f2783%22%3E%3Cspan class=%2267396b1d33e64559aa8deaf73300d262%22%3EHaga clic en la pestaña %3Cb%3ELog adicional%3C/b%3E.%3C/span%3E%3C/span%3E%3C/span%3E"}]}
			);

				action_f1072694581=new ActionMouse(
				{button:"leftclick",numberOfClicks:1,isDefault:true,modifiers:{alt:false,ctrl:false,shift:false},rectangle:{x:363,y:174,width:95,height:20},cursor:{file:"c0000038.png",x:410,y:184},route:"53794806",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"portal_content%2Fes.san.erp.carpeta_san%2Fes.san.erp.carpeta_mexico%2Fes.san.erp.capreta_fi%2Fes.san.erp.carpeta_roles%2Fes.san.erp.rol_zecc_mx_fi_lanto%2Fes.san.erp.workset_pagos%2Fes.san.erp.workset_contabilidad%2Fes.san.erp.workset_pagos%2Fes.san.erp.iview_pago_automatico_facturas",secondaryCsh:"",tertiaryCsh:"",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f1072694581"}
				);

			step_f132197363.addAction(action_f1072694581);

				note_f1072694581=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:527,y:96,width:211,height:42},file:"f1072694581.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:458,y:174},rectangle:{x:519,y:91,width:222,height:52},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f1072694581"}
				);

			step_f132197363.addNote(note_f1072694581);

		group5.addStep(step_f132197363);

		group6=new Group(
		{caption:"%26%238234%3BPagos%20autom%26%23225%3Bticos%3A%20Log%20adicional%26%238236%3B"}
		);

			step_53794806=new Step(
			{screen:{file:"i0000020.jpg",overlays:null},cursor:"c0000039.png",audio:"1326374078.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"53794806",content:[{text:"%3Cspan class=%22a8629dca081644448535edd0bf601133%22%3E%3Cspan class=%22bc568b842c2b477bae2988fd01aba069%22%3EHaga clic en el check %3Cb%3EVerificar vencimiento%3C/b%3E.%3C/span%3E%3C/span%3E"}]}
			);

				action_460828168=new ActionMouse(
				{button:"leftclick",numberOfClicks:1,isDefault:true,modifiers:{alt:false,ctrl:false,shift:false},rectangle:{x:26,y:254,width:12,height:12},cursor:{file:"c0000040.png",x:32,y:260},route:"f1594417356",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"portal_content%2Fes.san.erp.carpeta_san%2Fes.san.erp.carpeta_mexico%2Fes.san.erp.capreta_fi%2Fes.san.erp.carpeta_roles%2Fes.san.erp.rol_zecc_mx_fi_lanto%2Fes.san.erp.workset_pagos%2Fes.san.erp.workset_contabilidad%2Fes.san.erp.workset_pagos%2Fes.san.erp.iview_pago_automatico_facturas",secondaryCsh:"",tertiaryCsh:"",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_460828168"}
				);

			step_53794806.addAction(action_460828168);

				note_460828168=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:357,y:277,width:178,height:70},file:"460828168.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:38,y:266},rectangle:{x:349,y:272,width:189,height:80},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_460828168"}
				);

			step_53794806.addNote(note_460828168);

		group6.addStep(step_53794806);

			step_f1594417356=new Step(
			{screen:{file:"i0000020.jpg",overlays:[{rectangle:{x:29,y:257,width:7,height:7},file:"i0000021_1.jpg"}]},cursor:"c0000041.png",audio:"-784156891.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"f1594417356",content:[{text:"%3Cspan class=%22cce12e873662449a8a0d4732b76fb79b%22%3E%3Cspan class=%22b134cbd6ae8b44138afca3f18c1b7bbd%22%3EHaga clic en el check %3Cb%3ESelec. vía pago en caso de error%3C/b%3E.%3C/span%3E%3C/span%3E"}]}
			);

				action_f843114466=new ActionMouse(
				{button:"leftclick",numberOfClicks:1,isDefault:true,modifiers:{alt:false,ctrl:false,shift:false},rectangle:{x:26,y:308,width:12,height:12},cursor:{file:"c0000042.png",x:32,y:314},route:"1261569972",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"portal_content%2Fes.san.erp.carpeta_san%2Fes.san.erp.carpeta_mexico%2Fes.san.erp.capreta_fi%2Fes.san.erp.carpeta_roles%2Fes.san.erp.rol_zecc_mx_fi_lanto%2Fes.san.erp.workset_pagos%2Fes.san.erp.workset_contabilidad%2Fes.san.erp.workset_pagos%2Fes.san.erp.iview_pago_automatico_facturas",secondaryCsh:"",tertiaryCsh:"",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f843114466"}
				);

			step_f1594417356.addAction(action_f843114466);

				note_f843114466=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:317,y:263,width:206,height:80},file:"f843114466.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:38,y:308},rectangle:{x:309,y:258,width:217,height:90},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f843114466"}
				);

			step_f1594417356.addNote(note_f843114466);

		group6.addStep(step_f1594417356);

			step_1261569972=new Step(
			{screen:{file:"i0000020.jpg",overlays:[{rectangle:{x:29,y:257,width:7,height:7},file:"i0000022_1.jpg"},{rectangle:{x:29,y:311,width:7,height:7},file:"i0000022_2.jpg"}]},cursor:"c0000043.png",audio:"-925319392.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"1261569972",content:[{text:"%3Cspan class=%223c026668a9744bab93d8a9fcfde12696%22%3E%3Cspan class=%2222d5e67e4c0d4ba3a462f960671a07c8%22%3EHaga clic en el check %3Cb%3EPosiciones de documentos de pago%3C/b%3E.%3C/span%3E%3C/span%3E"}]}
			);

				action_f1479565693=new ActionMouse(
				{button:"leftclick",numberOfClicks:1,isDefault:true,modifiers:{alt:false,ctrl:false,shift:false},rectangle:{x:26,y:335,width:12,height:12},cursor:{file:"c0000044.png",x:32,y:341},route:"f620710590",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"portal_content%2Fes.san.erp.carpeta_san%2Fes.san.erp.carpeta_mexico%2Fes.san.erp.capreta_fi%2Fes.san.erp.carpeta_roles%2Fes.san.erp.rol_zecc_mx_fi_lanto%2Fes.san.erp.workset_pagos%2Fes.san.erp.workset_contabilidad%2Fes.san.erp.workset_pagos%2Fes.san.erp.iview_pago_automatico_facturas",secondaryCsh:"",tertiaryCsh:"",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f1479565693"}
				);

			step_1261569972.addAction(action_f1479565693);

				note_f1479565693=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:311,y:279,width:273,height:56},file:"f1479565693.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:38,y:335},rectangle:{x:303,y:274,width:284,height:66},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f1479565693"}
				);

			step_1261569972.addNote(note_f1479565693);

		group6.addStep(step_1261569972);

			step_f620710590=new Step(
			{screen:{file:"i0000020.jpg",overlays:[{rectangle:{x:29,y:257,width:7,height:7},file:"i0000023_1.jpg"},{rectangle:{x:29,y:311,width:7,height:7},file:"i0000023_2.jpg"},{rectangle:{x:29,y:338,width:7,height:7},file:"i0000023_3.jpg"}]},cursor:"c0000045.png",audio:"-1906550353.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"f620710590",content:[{text:"%3Cspan class=%22ecdbf856058b4a958619e4bb48ec0f9c%22%3E%3Cspan class=%22c71bd3bdd26f45a988af9685839a850a%22%3EHaga clic en el botón %3Cb%3E‪Menú de navegación%3C/b%3E‬, para visualizar la lista de pestañas ocultas.%3C/span%3E%3C/span%3E"}]}
			);

				action_f291662174=new ActionMouse(
				{button:"leftclick",numberOfClicks:1,isDefault:true,modifiers:{alt:false,ctrl:false,shift:false},rectangle:{x:660,y:174,width:16,height:18},cursor:{file:"c0000046.png",x:668,y:183},route:"f1751740042",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"portal_content%2Fes.san.erp.carpeta_san%2Fes.san.erp.carpeta_mexico%2Fes.san.erp.capreta_fi%2Fes.san.erp.carpeta_roles%2Fes.san.erp.rol_zecc_mx_fi_lanto%2Fes.san.erp.workset_pagos%2Fes.san.erp.workset_contabilidad%2Fes.san.erp.workset_pagos%2Fes.san.erp.iview_pago_automatico_facturas",secondaryCsh:"",tertiaryCsh:"",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f291662174"}
				);

			step_f620710590.addAction(action_f291662174);

				note_f291662174=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:418,y:234,width:172,height:118},file:"f291662174.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:660,y:192},rectangle:{x:410,y:229,width:183,height:128},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f291662174"}
				);

			step_f620710590.addNote(note_f291662174);

		group6.addStep(step_f620710590);

			step_f1751740042=new Step(
			{screen:{file:"i0000020.jpg",overlays:[{rectangle:{x:29,y:192,width:647,height:92},file:"i0000024_1.jpg"},{rectangle:{x:29,y:311,width:7,height:7},file:"i0000024_2.jpg"},{rectangle:{x:29,y:338,width:7,height:7},file:"i0000024_3.jpg"}]},cursor:"c0000047.png",audio:"1891024082.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"f1751740042",content:[{text:"%3Cspan class=%2274e6b3ec588d40f6bab44934142716b0%22%3E%3Cspan class=%2207ce8bf593e14efa98e1f23f9a91e207%22%3EHaga clic en el elemento ‪%3Cb%3EImpresión y sop.datos%3C/b%3E, del Menú de navegación‬.%3C/span%3E%3C/span%3E"}]}
			);

				action_276990267=new ActionMouse(
				{button:"leftclick",numberOfClicks:1,isDefault:true,modifiers:{alt:false,ctrl:false,shift:false},rectangle:{x:504,y:265,width:171,height:18},cursor:{file:"c0000048.png",x:589,y:274},route:"746183681",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"portal_content%2Fes.san.erp.carpeta_san%2Fes.san.erp.carpeta_mexico%2Fes.san.erp.capreta_fi%2Fes.san.erp.carpeta_roles%2Fes.san.erp.rol_zecc_mx_fi_lanto%2Fes.san.erp.workset_pagos%2Fes.san.erp.workset_contabilidad%2Fes.san.erp.workset_pagos%2Fes.san.erp.iview_pago_automatico_facturas",secondaryCsh:"",tertiaryCsh:"",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_276990267"}
				);

			step_f1751740042.addAction(action_276990267);

				note_276990267=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:281,y:271,width:189,height:93},file:"276990267.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:504,y:283},rectangle:{x:273,y:266,width:200,height:103},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_276990267"}
				);

			step_f1751740042.addNote(note_276990267);

		group6.addStep(step_f1751740042);

		group7=new Group(
		{caption:"%26%238234%3BPagos%20autom%26%23225%3Bticos%3A%20Impresi%26%23243%3Bn%20e%20ISD%26%238236%3B"}
		);

			step_746183681=new Step(
			{screen:{file:"i0000026.jpg",overlays:null},cursor:"c0000051.png",audio:"-219506887.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"746183681",content:[{text:"%3Cspan class=%22557193a27082463e80dfa85385748468%22%3E%3Cspan class=%22b24d942bec744907b7e337d1cbfff1a5%22%3E%3Cspan class=%22302073635b9c48b7b7d158a065063df8%22%3EHaga clic en el botón match code %3Cb%3EVariante,%3C/b%3E de la sección Impresión formularios / Intercambio soporte datos.%3C/span%3E%3C/span%3E%3C/span%3E"}]}
			);

				action_2107748921=new ActionMouse(
				{button:"leftclick",numberOfClicks:1,isDefault:true,modifiers:{alt:false,ctrl:false,shift:false},rectangle:{x:305,y:303,width:15,height:28},cursor:{file:"c0000052.png",x:312,y:317},route:"1507563703",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"portal_content%2Fes.san.erp.carpeta_san%2Fes.san.erp.carpeta_mexico%2Fes.san.erp.capreta_fi%2Fes.san.erp.carpeta_roles%2Fes.san.erp.rol_zecc_mx_fi_lanto%2Fes.san.erp.workset_pagos%2Fes.san.erp.workset_contabilidad%2Fes.san.erp.workset_pagos%2Fes.san.erp.iview_pago_automatico_facturas",secondaryCsh:"",tertiaryCsh:"",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_2107748921"}
				);

			step_746183681.addAction(action_2107748921);

				note_2107748921=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:464,y:277,width:248,height:94},file:"2107748921.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:320,y:317},rectangle:{x:456,y:272,width:259,height:104},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_2107748921"}
				);

			step_746183681.addNote(note_2107748921);

		group7.addStep(step_746183681);

		group8=new Group(
		{caption:"%26%238234%3BSelecci%26%23243%3Bn%20de%20variantes%20para%20ZRFFOMH2H%20%281%29%26%238236%3B"}
		);

			step_1507563703=new Step(
			{screen:{file:"i0000027.jpg",overlays:null},cursor:"c0000053.png",audio:"-1710002025.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"1507563703",content:[{text:"%3Cspan class=%2224c8cce5380546eda5df70701feae943%22%3E%3Cspan class=%22f24041e70791404ca6545686acaf101a%22%3E%3Cspan class=%22faaa3411c716486b8394bef01609703f%22%3EHaga doble clic en la Variante %3Cb%3E‪MX_H2H_0077%3C/b%3E, para efecto de este caso práctico‬.%3C/span%3E%3C/span%3E%3C/span%3E"}]}
			);

				action_f545022722=new ActionMouse(
				{button:"leftdoubleclick",numberOfClicks:2,isDefault:true,modifiers:{alt:false,ctrl:false,shift:false},rectangle:{x:283,y:210,width:100,height:17},cursor:{file:"c0000054.png",x:333,y:218},route:"f206859068",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"http_%2F%2Forionamerica.aacc.pre.corp%2Firj%2Fportal",secondaryCsh:"Pago%20autom%26%23225%3Btico%20de%20facturas%20-%20SAP%20NetWeaver%20Portal",tertiaryCsh:"ITSURGUI_1487114223136%7CobnNavIFrame%7C%26%23193%3Brea%20interna%20de%20desktop%20%20%20%7CFavoritos%20de%20portal%20%7CUntitled%7CLogon%20Error%20Message%7CisolatedWorkArea%7Citsframe1_20170215001528.3596410%7CITSTERMFRAME%7ChelpPanelContent",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f545022722"}
				);

			step_1507563703.addAction(action_f545022722);

				note_f545022722=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:578,y:272,width:195,height:117},file:"f545022722.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:383,y:227},rectangle:{x:570,y:267,width:206,height:127},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f545022722"}
				);

			step_1507563703.addNote(note_f545022722);

		group8.addStep(step_1507563703);

		group9=new Group(
		{caption:"%26%238234%3BPagos%20autom%26%23225%3Bticos%3A%20Impresi%26%23243%3Bn%20e%20ISD%26%238236%3B"}
		);

			step_f206859068=new Step(
			{screen:{file:"i0000028.jpg",overlays:null},cursor:"c0000055.png",audio:"674263955.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"f206859068",content:[{text:"%3Cspan class=%22c0f47fdbab6645d79fdf4e959e6162af%22%3E%3Cspan class=%220edebfb54e2b412198ac1819fee3823f%22%3EHaga clic en el botón ‪%3Cb%3EGrabar parámetros%3C/b%3E‬.%3C/span%3E%3C/span%3E"}]}
			);

				action_566189235=new ActionMouse(
				{button:"leftclick",numberOfClicks:1,isDefault:true,modifiers:{alt:false,ctrl:false,shift:false},rectangle:{x:229,y:42,width:119,height:12},cursor:{file:"c0000056.png",x:288,y:48},route:"1812520355",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"portal_content%2Fes.san.erp.carpeta_san%2Fes.san.erp.carpeta_mexico%2Fes.san.erp.capreta_fi%2Fes.san.erp.carpeta_roles%2Fes.san.erp.rol_zecc_mx_fi_lanto%2Fes.san.erp.workset_pagos%2Fes.san.erp.workset_contabilidad%2Fes.san.erp.workset_pagos%2Fes.san.erp.iview_pago_automatico_facturas",secondaryCsh:"",tertiaryCsh:"",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_566189235"}
				);

			step_f206859068.addAction(action_566189235);

				note_566189235=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:392,y:83,width:167,height:71},file:"566189235.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:348,y:54},rectangle:{x:384,y:78,width:178,height:81},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_566189235"}
				);

			step_f206859068.addNote(note_566189235);

		group9.addStep(step_f206859068);

			step_1812520355=new Step(
			{screen:{file:"i0000028.jpg",overlays:[{rectangle:{x:230,y:40,width:120,height:14},file:"i0000029_1.jpg"},{rectangle:{x:4,y:534,width:404,height:13},file:"i0000029_2.jpg"}]},cursor:"c0000057.png",audio:"197074070.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"1812520355",content:[{text:"%3Cspan class=%22a27838fb278d4b138b4d8f087888553d%22%3E%3Cspan class=%22f8a4c789ef9d409f9af5002a20d02114%22%3E%3Cspan class=%2219f2a090206a4771a68ee97b0aeb7006%22%3E%3Cspan class=%22f4c08f878868411d878b8547589f9925%22%3EHaga clic en el botón ‪%3Cb%3EMenú de navegación%3C/b%3E‬, para visualizar las pestañas ocultas.%3C/span%3E%3C/span%3E%3C/span%3E%3C/span%3E"}]}
			);

				action_1274306246=new ActionMouse(
				{button:"leftclick",numberOfClicks:1,isDefault:true,modifiers:{alt:false,ctrl:false,shift:false},rectangle:{x:660,y:174,width:16,height:18},cursor:{file:"c0000058.png",x:668,y:183},route:"f900170290",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"portal_content%2Fes.san.erp.carpeta_san%2Fes.san.erp.carpeta_mexico%2Fes.san.erp.capreta_fi%2Fes.san.erp.carpeta_roles%2Fes.san.erp.rol_zecc_mx_fi_lanto%2Fes.san.erp.workset_pagos%2Fes.san.erp.workset_contabilidad%2Fes.san.erp.workset_pagos%2Fes.san.erp.iview_pago_automatico_facturas",secondaryCsh:"",tertiaryCsh:"",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_1274306246"}
				);

			step_1812520355.addAction(action_1274306246);

				note_1274306246=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:308,y:92,width:328,height:74},file:"1274306246.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:660,y:174},rectangle:{x:300,y:87,width:339,height:84},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_1274306246"}
				);

			step_1812520355.addNote(note_1274306246);

				note_1874759805=new Note(
				{icon:{rectangle:{x:539,y:320,width:32,height:32},file:"noteicon_2.png"},image:{hyperlinks:null,rectangle:{x:571,y:320,width:266,height:121},file:"1812520355_1874759805.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:415,y:530},rectangle:{x:534,y:315,width:308,height:131},visible:true,cornerRadius:10,hotspot:{rectangle:{x:0,y:530,width:415,height:20},backColor:{a:255,r:0,g:0,b:255},borderColor:{a:255,r:255,g:0,b:0},borderWidth:3,transparency:100},modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:false,notetailAuto:false,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:""}
				);

			step_1812520355.addNote(note_1874759805);

		group9.addStep(step_1812520355);

			step_f900170290=new Step(
			{screen:{file:"i0000028.jpg",overlays:[{rectangle:{x:230,y:40,width:120,height:14},file:"i0000030_1.jpg"},{rectangle:{x:503,y:192,width:173,height:92},file:"i0000030_2.jpg"},{rectangle:{x:191,y:303,width:129,height:28},file:"i0000030_3.jpg"},{rectangle:{x:4,y:534,width:404,height:13},file:"i0000030_4.jpg"}]},cursor:"c0000059.png",audio:"1809021339.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"f900170290",content:[{text:"%3Cspan class=%22a490e0056e974e53a6601f46beccbb47%22%3E%3Cspan class=%22a61482cf2f9540ea81f13205bbbf9b6d%22%3E%3Cfont color=%22buttontext%22%3E%3Cspan id=%223eeec7b86f224c6facf985e7615fdc7a%22 style=%22PADDING-TOP: 0px; PADDING-LEFT: 0px; MARGIN: 0px; PADDING-RIGHT: 0px%22%3E %3Cspan class=%22eda890a9e5fc4ec285d9f96062a19e5d%22%3E%3Cspan class=%2274e6b3ec588d40f6bab44934142716b0%22%3E%3Cspan class=%2207ce8bf593e14efa98e1f23f9a91e207%22%3EHaga clic en el elemento ‪%3Cb%3EStatus%3C/b%3E, del Menú de navegación%3C/span%3E%3C/span%3E%3C/span%3E%3C/span%3E‬.%3C/font%3E%3C/span%3E%3C/span%3E"}]}
			);

				action_f1087205637=new ActionMouse(
				{button:"leftclick",numberOfClicks:1,isDefault:true,modifiers:{alt:false,ctrl:false,shift:false},rectangle:{x:528,y:193,width:147,height:18},cursor:{file:"c0000060.png",x:601,y:202},route:"482798579",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"portal_content%2Fes.san.erp.carpeta_san%2Fes.san.erp.carpeta_mexico%2Fes.san.erp.capreta_fi%2Fes.san.erp.carpeta_roles%2Fes.san.erp.rol_zecc_mx_fi_lanto%2Fes.san.erp.workset_pagos%2Fes.san.erp.workset_contabilidad%2Fes.san.erp.workset_pagos%2Fes.san.erp.iview_pago_automatico_facturas",secondaryCsh:"",tertiaryCsh:"",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f1087205637"}
				);

			step_f900170290.addAction(action_f1087205637);

				note_f1087205637=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:272,y:132,width:230,height:63},file:"f1087205637.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:528,y:193},rectangle:{x:264,y:127,width:241,height:73},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f1087205637"}
				);

			step_f900170290.addNote(note_f1087205637);

		group9.addStep(step_f900170290);

		group10=new Group(
		{caption:"%26%238234%3BPagos%20autom%26%23225%3Bticos%3A%20Status%26%238236%3B"}
		);

			step_482798579=new Step(
			{screen:{file:"i0000032.jpg",overlays:null},cursor:"c0000063.png",audio:"1311628478.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"482798579",content:[{text:"%3Cspan class=%2257a0c02100d24111a37911085caad4d8%22%3E%3Cspan class=%2235dd783235314545a3d7f0f4b859bb1a%22%3EHaga clic en el botón ‪%3Cb%3EPropuesta%3C/b%3E‬.%3C/span%3E%3C/span%3E"}]}
			);

				action_1873403680=new ActionMouse(
				{button:"leftclick",numberOfClicks:1,isDefault:true,modifiers:{alt:false,ctrl:false,shift:false},rectangle:{x:532,y:39,width:67,height:15},cursor:{file:"c0000064.png",x:565,y:46},route:"f819829746",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"portal_content%2Fes.san.erp.carpeta_san%2Fes.san.erp.carpeta_mexico%2Fes.san.erp.capreta_fi%2Fes.san.erp.carpeta_roles%2Fes.san.erp.rol_zecc_mx_fi_lanto%2Fes.san.erp.workset_pagos%2Fes.san.erp.workset_contabilidad%2Fes.san.erp.workset_pagos%2Fes.san.erp.iview_pago_automatico_facturas",secondaryCsh:"",tertiaryCsh:"",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_1873403680"}
				);

			step_482798579.addAction(action_1873403680);

				note_1873403680=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:297,y:120,width:156,height:42},file:"1873403680.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:532,y:54},rectangle:{x:289,y:115,width:167,height:52},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_1873403680"}
				);

			step_482798579.addNote(note_1873403680);

		group10.addStep(step_482798579);

		group11=new Group(
		{caption:"%26%238234%3BPlanificar%20propuesta%26%238236%3B"}
		);

			step_f819829746=new Step(
			{screen:{file:"i0000033.jpg",overlays:null},cursor:"c0000065.png",audio:"-798902491.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"f819829746",content:[{text:"%3Cspan class=%224421078767214df787d2096e6048732b%22%3E%3Cspan class=%224f9ef4a200f247368f23cb9841c795a5%22%3EHaga clic en el check %3Cb%3EEjecución inmediata%3C/b%3E.%3C/span%3E%3C/span%3E"}]}
			);

				action_2040419991=new ActionMouse(
				{button:"leftclick",numberOfClicks:1,isDefault:true,modifiers:{alt:false,ctrl:false,shift:false},rectangle:{x:721,y:326,width:12,height:12},cursor:{file:"c0000066.png",x:727,y:332},route:"825139551",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"http_%2F%2Forionamerica.aacc.pre.corp%2Firj%2Fportal",secondaryCsh:"Pago%20autom%26%23225%3Btico%20de%20facturas%20-%20SAP%20NetWeaver%20Portal",tertiaryCsh:"ITSURGUI_1487114223136%7CobnNavIFrame%7C%26%23193%3Brea%20interna%20de%20desktop%20%20%20%7CFavoritos%20de%20portal%20%7CUntitled%7CLogon%20Error%20Message%7CisolatedWorkArea%7Citsframe1_20170215001528.3596410%7CITSTERMFRAME%7ChelpPanelContent",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_2040419991"}
				);

			step_f819829746.addAction(action_2040419991);

				note_2040419991=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:742,y:254,width:171,height:63},file:"2040419991.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:733,y:326},rectangle:{x:734,y:249,width:182,height:73},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_2040419991"}
				);

			step_f819829746.addNote(note_2040419991);

		group11.addStep(step_f819829746);

			step_825139551=new Step(
			{screen:{file:"i0000033.jpg",overlays:[{rectangle:{x:604,y:322,width:127,height:16},file:"i0000034_1.jpg"}]},cursor:"c0000067.png",audio:"-940064992.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"825139551",content:[{text:"%3Cspan class=%229a64e6f53fd749c6b8049df670e314c2%22%3E%3Cspan class=%2245331b4144724ae5b56d01a4a79dd02d%22%3EHaga clic en el check %3Cb%3E‪Crear medio de pago%3C/b%3E‬.%3C/span%3E%3C/span%3E"}]}
			);

				action_1180963802=new ActionMouse(
				{button:"leftclick",numberOfClicks:1,isDefault:true,modifiers:{alt:false,ctrl:false,shift:false},rectangle:{x:471,y:433,width:14,height:13},cursor:{file:"c0000068.png",x:478,y:439},route:"f726505841",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"http_%2F%2Forionamerica.aacc.pre.corp%2Firj%2Fportal",secondaryCsh:"Pago%20autom%26%23225%3Btico%20de%20facturas%20-%20SAP%20NetWeaver%20Portal",tertiaryCsh:"ITSURGUI_1487114223136%7CobnNavIFrame%7C%26%23193%3Brea%20interna%20de%20desktop%20%20%20%7CFavoritos%20de%20portal%20%7CUntitled%7CLogon%20Error%20Message%7CisolatedWorkArea%7Citsframe1_20170215001528.3596410%7CITSTERMFRAME%7ChelpPanelContent",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_1180963802"}
				);

			step_825139551.addAction(action_1180963802);

				note_1180963802=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:556,y:480,width:200,height:42},file:"1180963802.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:485,y:446},rectangle:{x:548,y:475,width:211,height:52},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_1180963802"}
				);

			step_825139551.addNote(note_1180963802);

		group11.addStep(step_825139551);

			step_f726505841=new Step(
			{screen:{file:"i0000033.jpg",overlays:[{rectangle:{x:604,y:322,width:127,height:16},file:"i0000035_1.jpg"},{rectangle:{x:476,y:437,width:7,height:7},file:"i0000035_2.jpg"}]},cursor:"c0000069.png",audio:"-1921295953.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"f726505841",content:[{text:"%3Cspan class=%22780c094a06a74017b03f3e93829f93b5%22%3E%3Cspan class=%22f7f0182a8a074577b87305376355027f%22%3EHaga clic en el botón ‪%3Cb%3EPlanificar (Entrada)‬%3C/b%3E para continuar.%3C/span%3E%3C/span%3E"}]}
			);

				action_f558739226=new ActionMouse(
				{button:"leftclick",numberOfClicks:1,isDefault:true,modifiers:{alt:false,ctrl:false,shift:false},rectangle:{x:836,y:494,width:16,height:15},cursor:{file:"c0000070.png",x:844,y:501},route:"f202005522",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"http_%2F%2Forionamerica.aacc.pre.corp%2Firj%2Fportal",secondaryCsh:"Pago%20autom%26%23225%3Btico%20de%20facturas%20-%20SAP%20NetWeaver%20Portal",tertiaryCsh:"ITSURGUI_1487114223136%7CobnNavIFrame%7C%26%23193%3Brea%20interna%20de%20desktop%20%20%20%7CFavoritos%20de%20portal%20%7CUntitled%7CLogon%20Error%20Message%7CisolatedWorkArea%7Citsframe1_20170215001528.3596410%7CITSTERMFRAME%7ChelpPanelContent",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f558739226"}
				);

			step_f726505841.addAction(action_f558739226);

				note_f558739226=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:549,y:524,width:234,height:63},file:"f558739226.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:836,y:509},rectangle:{x:541,y:519,width:245,height:73},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f558739226"}
				);

			step_f726505841.addNote(note_f558739226);

		group11.addStep(step_f726505841);

		group12=new Group(
		{caption:"%26%238234%3BPagos%20autom%26%23225%3Bticos%3A%20Status%26%238236%3B"}
		);

			step_f202005522=new Step(
			{screen:{file:"i0000036.jpg",overlays:null},cursor:"c0000071.png",audio:"1876278482.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"f202005522",content:[{text:"%3Cspan class=%2299f45e62bc3c4e078547e69fb7a34b47%22%3E%3Cspan class=%22c34fb111a3bf4003890259abbbbbfe56%22%3EHaga clic en el botón ‪%3Cb%3EStatus%3C/b%3E‬.%3C/span%3E%3C/span%3E"}]}
			);

				action_1162845618=new ActionMouse(
				{button:"leftclick",numberOfClicks:1,isDefault:true,modifiers:{alt:false,ctrl:false,shift:false},rectangle:{x:482,y:42,width:46,height:10},cursor:{file:"c0000072.png",x:505,y:47},route:"f251606472",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"portal_content%2Fes.san.erp.carpeta_san%2Fes.san.erp.carpeta_mexico%2Fes.san.erp.capreta_fi%2Fes.san.erp.carpeta_roles%2Fes.san.erp.rol_zecc_mx_fi_lanto%2Fes.san.erp.workset_pagos%2Fes.san.erp.workset_contabilidad%2Fes.san.erp.workset_pagos%2Fes.san.erp.iview_pago_automatico_facturas",secondaryCsh:"",tertiaryCsh:"",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_1162845618"}
				);

			step_f202005522.addAction(action_1162845618);

				note_1162845618=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:584,y:88,width:222,height:42},file:"1162845618.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:528,y:52},rectangle:{x:576,y:83,width:233,height:52},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_1162845618"}
				);

			step_f202005522.addNote(note_1162845618);

				note_f567383261=new Note(
				{icon:{rectangle:{x:347,y:413,width:32,height:32},file:"noteicon_2.png"},image:{hyperlinks:null,rectangle:{x:379,y:413,width:300,height:78},file:"f202005522_f567383261.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:287,y:530},rectangle:{x:342,y:408,width:342,height:88},visible:true,cornerRadius:10,hotspot:{rectangle:{x:0,y:530,width:287,height:20},backColor:{a:255,r:0,g:0,b:255},borderColor:{a:255,r:255,g:0,b:0},borderWidth:3,transparency:100},modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:false,notetailAuto:false,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:""}
				);

			step_f202005522.addNote(note_f567383261);

		group12.addStep(step_f202005522);

			step_f251606472=new Step(
			{screen:{file:"i0000036.jpg",overlays:[{rectangle:{x:483,y:39,width:378,height:16},file:"i0000037_1.jpg"},{rectangle:{x:27,y:283,width:206,height:13},file:"i0000037_2.jpg"},{rectangle:{x:20,y:536,width:355,height:11},file:"i0000037_3.jpg"}]},cursor:"c0000073.png",audio:"-234252487.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"f251606472",content:[{text:"%3Cspan class=%2247f06dcafacc463485014a59d90798c9%22%3E%3Cspan class=%223c8d22abb9544ab28a380d598423b466%22%3EHaga clic en el botón ‪%3Cb%3EPropuesta%3C/b%3E‬.%3C/span%3E%3C/span%3E"}]}
			);

				action_1564408102=new ActionMouse(
				{button:"leftclick",numberOfClicks:1,isDefault:true,modifiers:{alt:false,ctrl:false,shift:false},rectangle:{x:722,y:41,width:64,height:12},cursor:{file:"c0000074.png",x:754,y:47},route:"820126512",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"portal_content%2Fes.san.erp.carpeta_san%2Fes.san.erp.carpeta_mexico%2Fes.san.erp.capreta_fi%2Fes.san.erp.carpeta_roles%2Fes.san.erp.rol_zecc_mx_fi_lanto%2Fes.san.erp.workset_pagos%2Fes.san.erp.workset_contabilidad%2Fes.san.erp.workset_pagos%2Fes.san.erp.iview_pago_automatico_facturas",secondaryCsh:"",tertiaryCsh:"",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_1564408102"}
				);

			step_f251606472.addAction(action_1564408102);

				note_1564408102=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:406,y:107,width:239,height:42},file:"1564408102.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:722,y:53},rectangle:{x:398,y:102,width:250,height:52},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_1564408102"}
				);

			step_f251606472.addNote(note_1564408102);

				note_f926610053=new Note(
				{icon:{rectangle:{x:486,y:401,width:32,height:32},file:"noteicon_2.png"},image:{hyperlinks:null,rectangle:{x:518,y:401,width:283,height:96},file:"f251606472_f926610053.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:381,y:530},rectangle:{x:481,y:396,width:325,height:106},visible:true,cornerRadius:10,hotspot:{rectangle:{x:0,y:530,width:381,height:20},backColor:{a:255,r:0,g:0,b:255},borderColor:{a:255,r:255,g:0,b:0},borderWidth:3,transparency:100},modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:false,notetailAuto:false,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:""}
				);

			step_f251606472.addNote(note_f926610053);

		group12.addStep(step_f251606472);

		group13=new Group(
		{caption:"%26%238234%3BVisualizar%20propuestas%20de%20pago%3A%20Pagos%26%238236%3B"}
		);

			step_820126512=new Step(
			{screen:{file:"i0000038.jpg",overlays:null},cursor:"c0000075.png",audio:"-375414988.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"820126512",content:[{text:"%3Cspan class=%22027531f0b20c4d5996ed01bc7bb4af63%22%3E%3Cspan class=%2247d7c017ec0e4fca9d789ceacfcb81a1%22%3EHaga clic en el botón ‪%3Cb%3EAtrás%3C/b%3E, para regresar a la pantalla anterior‬.%3C/span%3E%3C/span%3E"}]}
			);

				action_f1729391624=new ActionMouse(
				{button:"leftclick",numberOfClicks:1,isDefault:true,modifiers:{alt:false,ctrl:false,shift:false},rectangle:{x:229,y:39,width:42,height:16},cursor:{file:"c0000076.png",x:250,y:47},route:"f253100456",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"portal_content%2Fes.san.erp.carpeta_san%2Fes.san.erp.carpeta_mexico%2Fes.san.erp.capreta_fi%2Fes.san.erp.carpeta_roles%2Fes.san.erp.rol_zecc_mx_fi_lanto%2Fes.san.erp.workset_pagos%2Fes.san.erp.workset_contabilidad%2Fes.san.erp.workset_pagos%2Fes.san.erp.iview_pago_automatico_facturas",secondaryCsh:"",tertiaryCsh:"",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f1729391624"}
				);

			step_820126512.addAction(action_f1729391624);

				note_f1729391624=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:425,y:109,width:238,height:63},file:"f1729391624.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:271,y:55},rectangle:{x:417,y:104,width:249,height:73},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f1729391624"}
				);

			step_820126512.addNote(note_f1729391624);

				note_143405623=new Note(
				{icon:{rectangle:{x:220,y:256,width:32,height:32},file:"noteicon_2.png"},image:{hyperlinks:null,rectangle:{x:252,y:256,width:236,height:42},file:"820126512_143405623.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:542,y:212},rectangle:{x:215,y:251,width:278,height:52},visible:true,cornerRadius:10,hotspot:{rectangle:{x:19,y:192,width:1047,height:20},backColor:{a:255,r:0,g:0,b:255},borderColor:{a:255,r:255,g:0,b:0},borderWidth:3,transparency:100},modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:false,notetailAuto:false,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:""}
				);

			step_820126512.addNote(note_143405623);

		group13.addStep(step_820126512);

		group14=new Group(
		{caption:"%26%238234%3BPagos%20autom%26%23225%3Bticos%3A%20Status%26%238236%3B"}
		);

			step_f253100456=new Step(
			{screen:{file:"i0000039.jpg",overlays:null},cursor:"c0000077.png",audio:"659518355.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"f253100456",content:[{text:"%3Cspan class=%22248c5009b5aa48dcb673545ca4418f7b%22%3E%3Cspan class=%22e21a688ca8c9445ba669dc0608f24110%22%3EHaga clic en el botón %3Cb%3E‪Ejecución de pago%3C/b%3E‬.%3C/span%3E%3C/span%3E"}]}
			);

				action_f284643475=new ActionMouse(
				{button:"leftclick",numberOfClicks:1,isDefault:true,modifiers:{alt:false,ctrl:false,shift:false},rectangle:{x:532,y:39,width:116,height:15},cursor:{file:"c0000078.png",x:590,y:46},route:"f39375803",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"portal_content%2Fes.san.erp.carpeta_san%2Fes.san.erp.carpeta_mexico%2Fes.san.erp.capreta_fi%2Fes.san.erp.carpeta_roles%2Fes.san.erp.rol_zecc_mx_fi_lanto%2Fes.san.erp.workset_pagos%2Fes.san.erp.workset_contabilidad%2Fes.san.erp.workset_pagos%2Fes.san.erp.iview_pago_automatico_facturas",secondaryCsh:"",tertiaryCsh:"",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f284643475"}
				);

			step_f253100456.addAction(action_f284643475);

				note_f284643475=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:309,y:117,width:160,height:73},file:"f284643475.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:532,y:54},rectangle:{x:301,y:112,width:171,height:83},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f284643475"}
				);

			step_f253100456.addNote(note_f284643475);

		group14.addStep(step_f253100456);

		group15=new Group(
		{caption:"%26%238234%3BPlanificar%20pago%26%238236%3B"}
		);

			step_f39375803=new Step(
			{screen:{file:"i0000040.jpg",overlays:null},cursor:"c0000079.png",audio:"182328470.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"f39375803",content:[{text:"%3Cspan class=%2205c89f44095049de9d9b47de10a9fa89%22%3E%3Cspan class=%22d67e44a2938b468b9b7f249146c7b30f%22%3EHaga clic en el botón %3Cb%3E‪Planificar (Entrada)%3C/b%3E‬, para continuar.%3C/span%3E%3C/span%3E"}]}
			);

				action_f960300343=new ActionMouse(
				{button:"leftclick",numberOfClicks:1,isDefault:true,modifiers:{alt:false,ctrl:false,shift:false},rectangle:{x:836,y:494,width:16,height:15},cursor:{file:"c0000080.png",x:844,y:501},route:"1200731416",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"http_%2F%2Forionamerica.aacc.pre.corp%2Firj%2Fportal",secondaryCsh:"Pago%20autom%26%23225%3Btico%20de%20facturas%20-%20SAP%20NetWeaver%20Portal",tertiaryCsh:"ITSURGUI_1487114223136%7CobnNavIFrame%7C%26%23193%3Brea%20interna%20de%20desktop%20%20%20%7CFavoritos%20de%20portal%20%7CUntitled%7CLogon%20Error%20Message%7CisolatedWorkArea%7Citsframe1_20170215001528.3596410%7CITSTERMFRAME%7ChelpPanelContent",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f960300343"}
				);

			step_f39375803.addAction(action_f960300343);

				note_f960300343=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:488,y:520,width:232,height:71},file:"f960300343.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:836,y:509},rectangle:{x:480,y:515,width:243,height:81},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f960300343"}
				);

			step_f39375803.addNote(note_f960300343);

		group15.addStep(step_f39375803);

		group16=new Group(
		{caption:"%26%238234%3BPagos%20autom%26%23225%3Bticos%3A%20Status%26%238236%3B"}
		);

			step_1200731416=new Step(
			{screen:{file:"i0000041.jpg",overlays:null},cursor:"c0000081.png",audio:"1802402203.mp3",autoPlaybackTime:4000,helpText:"Su%20respuesta%20no%20fue%20correcta.%20%26%23191%3BDesea%20obtener%20ayuda%3F",assess:true,composite:false,transcript:"",tooltips:null,id:"1200731416",content:[{text:"%3Cspan class=%2292e67332d1384529bfd3b7a6b6dbd1bb%22%3E%3Cspan class=%22eee41574fa6c4560b51f25b62f9773e4%22%3EHaga clic en el botón ‪%3Cb%3EStatus%3C/b%3E‬.%3C/span%3E%3C/span%3E"}]}
			);

				action_f691074516=new ActionMouse(
				{button:"leftclick",numberOfClicks:1,isDefault:true,modifiers:{alt:false,ctrl:false,shift:false},rectangle:{x:482,y:39,width:46,height:15},cursor:{file:"c0000082.png",x:505,y:46},route:"f1809391649",borderColor:{a:255,r:255,g:0,b:0},borderWidth:2,flashing:true,isRTL:false,hotspotStandard:true,hotspotAuto:true,assessHelpMode:1,selfHelpMode:1,primaryCsh:"portal_content%2Fes.san.erp.carpeta_san%2Fes.san.erp.carpeta_mexico%2Fes.san.erp.capreta_fi%2Fes.san.erp.carpeta_roles%2Fes.san.erp.rol_zecc_mx_fi_lanto%2Fes.san.erp.workset_pagos%2Fes.san.erp.workset_contabilidad%2Fes.san.erp.workset_pagos%2Fes.san.erp.iview_pago_automatico_facturas",secondaryCsh:"",tertiaryCsh:"",assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f691074516"}
				);

			step_1200731416.addAction(action_f691074516);

				note_f691074516=new Note(
				{icon:{rectangle:{x:0,y:0,width:0,height:0},file:"noteicon_0.png"},image:{hyperlinks:null,rectangle:{x:610,y:122,width:213,height:43},file:"f691074516.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:528,y:54},rectangle:{x:602,y:117,width:224,height:53},visible:true,cornerRadius:10,modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:true,notetailAuto:true,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:"action_f691074516"}
				);

			step_1200731416.addNote(note_f691074516);

				note_f238291598=new Note(
				{icon:{rectangle:{x:381,y:409,width:32,height:32},file:"noteicon_2.png"},image:{hyperlinks:null,rectangle:{x:413,y:409,width:308,height:92},file:"1200731416_f238291598.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:256,y:530},rectangle:{x:376,y:404,width:350,height:102},visible:true,cornerRadius:10,hotspot:{rectangle:{x:0,y:530,width:256,height:20},backColor:{a:255,r:0,g:0,b:255},borderColor:{a:255,r:255,g:0,b:0},borderWidth:3,transparency:100},modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:false,notetailAuto:false,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:""}
				);

			step_1200731416.addNote(note_f238291598);

		group16.addStep(step_1200731416);

		group17=new Group(
		{caption:"Fin%20de%20la%20simulaci%26%23243%3Bn"}
		);

			step_f1809391649=new Step(
			{screen:{file:"i0000042.jpg",overlays:null},cursor:"",audio:"1305009342.mp3",autoPlaybackTime:0,helpText:"",assess:false,composite:false,transcript:"",tooltips:null,id:"f1809391649",content:[{text:"Fin de la simulación"}]}
			);

				note_f567675877=new Note(
				{icon:{rectangle:{x:340,y:262,width:32,height:32},file:"noteicon_2.png"},image:{hyperlinks:null,rectangle:{x:372,y:262,width:230,height:71},file:"f1809391649_f567675877.jpg"},backColor:{a:255,r:255,g:255,b:255},borderColor:{a:255,r:91,g:90,b:91},borderWidth:2,pointer:{x:273,y:309},rectangle:{x:335,y:257,width:272,height:81},visible:true,cornerRadius:10,hotspot:{rectangle:{x:21,y:252,width:252,height:115},backColor:{a:255,r:0,g:0,b:255},borderColor:{a:255,r:255,g:0,b:0},borderWidth:3,transparency:100},modes:[0,1],assessHelpMode:1,selfHelpMode:1,notetailStandard:false,notetailAuto:false,assessTime:0,selfTime:0,standardTime:0,displayNoteTime:0,duration:0,entryAnimation:"display",exitAnimation:"hide",selfEntryAnimation:"display",standardEntryAnimation:"display",assessEntryAnimation:"display",actionid:""}
				);

			step_f1809391649.addNote(note_f567675877);

		group17.addStep(step_f1809391649);




		Utils.debug.trace('Structure initialized successfully');		
	}
	catch(e)
	{
		Utils.debug.trace('Error: Cannot inialize structure: '+(e.description || e));
	}
};
