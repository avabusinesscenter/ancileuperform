﻿/**
lang.js (dynamic)
Published by ANCILE uPerform
- Static language constants populated by the publish routine
*/

if(!window.Lang){window.Lang = {};}
	
Lang.CANNOT_OPEN_DEBUG_WIN = "Error: No se puede abrir la ventana de depuración - Desactive todos los bloqueadores de ventanas emergentes para poder utilizar esta función.%5CnEl contenido a depurar se mostrará en un cuadro de alerta después de que haga clic en 'Aceptar'.";
Lang.AICC_CHECK_BEFORE_UNLOAD = "ADVERTENCIA: Para poder recibir un crédito, debe utilizar uno de los botones de salida.  ¿Realmente desea salir?";
Lang.EXIT_CONFIRMATION = "¿Está seguro de que desea salir de este curso?";
Lang.ENTER_USER_NAME = "Ingrese un nombre de usuario para los resultados de la evaluación";

Lang.UI_CLOSE = "Cerrar";
Lang.UI_SUBMIT = "Enviar";
Lang.UI_LABEL_TRANSCRIPT = "Informe de notas";
Lang.UI_LABEL_AUDIO_ENABLED = "Sonido activado";
Lang.UI_LABEL_AUDIO_DISABLED = "Sonido desactivado";
Lang.UI_LABEL_STEP_NUMBER = "Paso %s de %t";
Lang.UI_LABEL_NEXT = "Siguiente";
Lang.UI_LABEL_PREVIOUS = "Anterior";
Lang.UI_LABEL_PLAY = "Reproducir";
Lang.UI_LABEL_PAUSE = "Pausa";
Lang.YES = "Sí";
Lang.NO = "No";
Lang.INFORMATION = "Información";
Lang.TOGGLE_STEPS = "Alternar pasos";

Lang.HELP_PROMPT = "Su respuesta no fue correcta. ¿Desea obtener ayuda?";
Lang.SIM_END = "Finalizar la lección";
Lang.SIM_RESTART = "Reiniciar la lección";
Lang.LESSON_NAME = "Nombre de la lección";
Lang.TOTAL_STEPS = "Total de paso(s)";
Lang.NUMBER_INCORRECT_STEPS = "Total incorrecto";
Lang.ACCURACY = "Precisión";
Lang.INCORRECT_STEPS = "Número(s) de paso(s) incorrecto(s)";
Lang.BOOKMARK = "Marcador";
Lang.BOOKMARK_TEXT = "La última vez que utilizó esta simulación, se detuvo en el paso %s. ¿Desea volver al lugar donde se detuvo?";
Lang.PASS = "Respuesta de aprobado";
Lang.FAIL = "Respuesta de suspenso";
Lang.FINISHED = "Está al final de la lección.";
Lang.SEND_RESULTS = "Enviar resultado";
Lang.CREATED_BY = "Creado por";
Lang.PUBLISH_DATE = "Fecha de publicación";
Lang.COPYRIGHT = "Derechos de autor";
Lang.MODENAME_AUTO = "Videotutorial";
Lang.MODENAME_SELFTEST = "Tutorial de autoevaluación";
Lang.MODENAME_STANDARD = "Práctica Paso a Paso";
Lang.MODENAME_ASSESSMENT = "Evaluación de la Transacción";
Lang.ENDMESSAGE_AUTO = "Ha finalizado la lección.";
Lang.ENDMESSAGE_SELFTEST = "Ha finalizado la lección.";
Lang.ENDMESSAGE_STANDARD = "Ha finalizado la lección.";
Lang.ENDMESSAGE_ASSESSMENT = "Ha finalizado la lección.";
Lang.STEPWINDOW_CAPTION = "Ventana del paso";
Lang.STEPWINDOW_DESCRIPTION = "Descripción";
Lang.STEPWINDOW_DONE = "Finalizado";
Lang.STEPWINDOW_INSERTBOOKMARK = "Insertar marcador";
Lang.STEPWINDOW_REMOVEBOOKMARK = "Quitar marcador";
Lang.STEPWINDOW_CREATEPRINTABLE = "Crear imprimible";
Lang.STEPWINDOW_RESTORESTEPS = "Restaurar pasos";
Lang.STEPWINDOW_HIDESTEPS = "Ocultar pasos";
Lang.STEPWINDOW_OVERLAY = "Superponer";
Lang.STEPWINDOW_TILE = "Mosaico";
Lang.STEPWINDOW_OPEN = "Abrir";
Lang.STEPWINDOW_CLOSE = "Cerrar";
Lang.STEPWINDOW_STEPWINDOW = "Ventana del paso";
Lang.TOGGLE_MUTE = "Alternar silencio";
Lang.ASSESSMENT_ERROR_POSTING_RESULTS = "Se ha producido un error al intentar publicar los resultados";

Lang.FLASH_WARNING_TITLE = "¡Advertencia!";
Lang.FLASH_WARNING_IT_APPEARS = "Aparentemente usted no tiene instalada la versión correcta del complemento de Flash para ver este software didáctico.";
Lang.FLASH_WARNING_CLICK_HERE_TO_INSTALL = "Haga clic aquí para instalar el complemento";
Lang.FLASH_WARNING_CONTACT_YOUR_ADMIN = "Para obtener ayuda sobre la instalación del complemento de Flash, comuníquese con el administrador del sistema.";
Lang.FLASH_WARNING_CURRENT_VERSION = "Versión instalada actualmente";
Lang.FLASH_WARNING_REQUIRED_VERSION = "Versión requerida";
Lang.FLASH_WARNING_IT_APPEARS_UNSUPPORTED = "Esta plataforma no admite Flash Player. Alguna parte de audio puede no estar disponible.";
Lang.FLASH_WARNING_IT_APPEARS_UNSUPPORTED_AICC = "Esta plataforma no admite Flash Player. Su progreso no se guardará para esta sesión.";
Lang.FLASH_WARNING_DO_NOT_SHOW_MESSAGE_AGAIN = "No volver a mostrar este mensaje.";
Lang.FLASH_WARNING_VERSION_UNSUPPORTED = "No se admite";

Lang.ACCESSIBILITY_OPEN = "Abrir";
Lang.ACCESSIBILITY_CLOSED =  "Cerrada";
Lang.ACCESSIBILITY_SELECTED =  "Seleccionado";
Lang.ACCESSIBILITY_DESELECTED =  "No seleccionado";
Lang.ACCESSIBILITY_MENU_ITEM = "Elemento del menú";
Lang.ACCESSIBILITY_ON = "ACTIVADO";
Lang.ACCESSIBILITY_OFF = "DESACTIVADO";
